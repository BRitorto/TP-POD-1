#!/bin/bash

java  -cp 'lib/jars/*' "Server" $*

